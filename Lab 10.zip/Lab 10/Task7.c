#include <stdio.h>

float totalCash = 0.0f;

void deposit(float amount)
{
    totalCash += amount;
    printf("Deposited %.2f\n", amount);
}

void showTotal(void)
{
    printf("Total cash in bank: %.2f", totalCash);
}

int main(void)
{
    deposit(5000.0f);
    deposit(2500.0f);
    deposit(1000.0f);

    showTotal();

    return 0;
}
