#include <stdio.h>

int getToken(void)
{
    static int token = 0;

    token++;
    return token;
}

int main(void)
{
    int i;

    for (i = 1; i <= 5; i++)
    {
        printf("Patient %d -> Token No: %d\n", i, getToken());
    }

    return 0;
}
